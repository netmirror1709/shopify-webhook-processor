const amqp = require('amqplib');
const axios = require('axios');
const { Pool } = require('pg');

require('dotenv').config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL || "postgresql://postgres:postgres@postgres:5432/syncdb"
});

const QUEUE_NAME = process.env.RABBITMQ_QUEUE || 'shopify_inventory_queue';
const PREFETCH_COUNT = parseInt(process.env.CONSUMER_PREFETCH_COUNT) || 1;

let connection = null;
let channel = null;
let isShuttingDown = false;

async function startConsumer() {
  console.log('🚀 Starting Shopify Inventory Sync Processor...');

  await connect();
  await consumeMessage(async (message) => {
    if (isShuttingDown) {
      console.log('⚠️ Shutting down, skipping new messages');
      return;
    }

    console.log('Received message:', message);
    const body = message.body || message;
    const shopDomain = message.shopDomain;
    const inventoryItemId = body.inventory_item_id;
    const locationId = body.location_id;
    const available = body.available;
    const updatedAtStr = body.updated_at;

    if (!inventoryItemId || !locationId || available === undefined || !updatedAtStr) {
      console.warn('⚠️ Invalid inventory update payload', body);
      return;
    }

    const updatedAt = new Date(updatedAtStr);

    console.log(`📦 Processing inventory update for ${shopDomain}: Item ${inventoryItemId} Location ${locationId} -> ${available}`);
    await syncInventoryLevel({ inventoryItemId, locationId, available, updatedAt });
  });

  console.log('✅ Consumer is running and listening for messages...');
}

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

async function connect(retries = 10, delay = 5000) {
  if (connection && channel) return channel;

  for (let i = 0; i < retries; i++) {
    try {
      connection = await amqp.connect(process.env.RABBITMQ_URL);
      channel = await connection.createChannel();

      await channel.assertQueue(QUEUE_NAME, { durable: true });
      await channel.prefetch(PREFETCH_COUNT);

      connection.on('error', (err) => {
        console.error('❌ RabbitMQ Connection Error:', err);
        connection = null;
        channel = null;
      });

      console.log('✅ Connected to RabbitMQ');
      return channel;
    } catch (error) {
      console.error(`❌ Failed to connect to RabbitMQ (attempt ${i + 1}/${retries}):`, error.message);
      if (i === retries - 1) throw error;
      await sleep(delay);
    }
  }
}

async function consumeMessage(onMessage) {
  const ch = await connect();

  return ch.consume(QUEUE_NAME, async (msg) => {
    if (!msg) return;

    try {
      const content = JSON.parse(msg.content.toString());
      await onMessage(content);
      ch.ack(msg);
      console.log('✅ Message acknowledged');
    } catch (error) {
      console.error('❌ Error processing message:', error);
      ch.nack(msg, false, true);
    }
  }, { noAck: false });
}

const SHOPIFY_API_VERSION = '2026-01';

async function adjustShopifyInventory({ inventoryItemId, locationId, delta, shopDomain, storeAccessKey }) {
  const url = `https://${shopDomain}/admin/api/${SHOPIFY_API_VERSION}/graphql.json`;

  const query = `
    mutation inventoryAdjustQuantities($input: InventoryAdjustQuantitiesInput!) {
      inventoryAdjustQuantities(input: $input) {
        inventoryAdjustmentGroup {
          createdAt
          reason
          changes {
            name
            delta
          }
        }
        userErrors {
          field
          message
        }
      }
    }
  `;

  const variables = {
    input: {
      reason: "correction",
      name: "available",
      changes: [
        {
          delta: delta,
          inventoryItemId: `gid://shopify/InventoryItem/${String(inventoryItemId).split('/').pop()}`,
          locationId: `gid://shopify/Location/${String(locationId).split('/').pop()}`
        }
      ]
    }
  };

  const response = await axios.post(
    url,
    { query, variables },
    {
      headers: {
        'X-Shopify-Access-Token': storeAccessKey,
        'Content-Type': 'application/json'
      },
      timeout: 10000
    }
  );

  if (response.data.errors) {
    throw new Error(JSON.stringify(response.data.errors));
  }

  const data = response.data && response.data.data;
  const userErrors = data && data.inventoryAdjustQuantities && data.inventoryAdjustQuantities.userErrors;
  if (userErrors && userErrors.length > 0) {
    throw new Error(JSON.stringify(userErrors));
  }

  return response.data;
}

async function syncInventoryLevel({ inventoryItemId, locationId, available, updatedAt }) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // 1. Find groupId for the incoming variant (fuzzy match for GID vs numeric ID)
    const stringInventoryId = String(inventoryItemId);
    const stringLocationId = String(locationId);

    const groupLookup = await client.query(
      `SELECT "groupId" FROM "InventoryGroupVariant" 
       WHERE "inventoryItemId" LIKE $1 AND "locationId" LIKE $2`,
      [`%${stringInventoryId}%`, `%${stringLocationId}%`]
    );

    if (groupLookup.rows.length === 0) {
      console.log(`ℹ️ Variant not found in any inventory group for ID: ${stringInventoryId} Loc: ${stringLocationId}. Ignoring.`);
      await client.query('ROLLBACK');
      return;
    }

    const groupId = groupLookup.rows[0].groupId;

    // 2. Lock all variants in this group
    const groupVariants = await client.query(
      `SELECT id, "inventoryItemId", "locationId", "storeDomain", "storeAccessKey", available, "updatedAt"
       FROM "InventoryGroupVariant"
       WHERE "groupId" = $1
       FOR UPDATE`,
      [groupId]
    );

    console.log(`🔒 Locked ${groupVariants.rows.length} rows for group ${groupId}`);

    // 3. Check for source variant in the group and validate updatedAt
    const sourceVariant = groupVariants.rows.find(r =>
      r.inventoryItemId.includes(stringInventoryId) && r.locationId.includes(stringLocationId)
    );

    if (sourceVariant && sourceVariant.updatedAt) {
      const dbUpdatedAt = new Date(sourceVariant.updatedAt);
      if (updatedAt < dbUpdatedAt) {
        console.log(`⚠️ Ignored old webhook for ${sourceVariant.storeDomain} (Incoming: ${updatedAt.toISOString()}, DB: ${dbUpdatedAt.toISOString()})`);
        await client.query('ROLLBACK');
        return;
      }
    }

    // 4. Update all variants in the group
    for (const variant of groupVariants.rows) {
      const isSource = variant.inventoryItemId.includes(stringInventoryId) && variant.locationId.includes(stringLocationId);

      if (variant.available !== available) {
        if (!isSource) {
          // If not the source variant, update on Shopify
          const delta = available - (variant.available || 0);
          console.log(`🔄 Syncing to ${variant.storeDomain}: available ${variant.available} -> ${available} (delta: ${delta})`);

          try {
            await adjustShopifyInventory({
              inventoryItemId: variant.inventoryItemId.split('/').pop(),
              locationId: variant.locationId.split('/').pop(),
              delta: delta,
              shopDomain: variant.storeDomain,
              storeAccessKey: variant.storeAccessKey
            });
          } catch (error) {
            console.error(`❌ Failed to update Shopify for ${variant.storeDomain}:`, error.message);
            // Optionally decide if one failure should roll back everything.
            // Requirement says "update that inventory on that store", might imply individual updates.
            // But usually for consistency, we rollback.
            throw error;
          }
        }

        // Update DB
        await client.query(
          `UPDATE "InventoryGroupVariant" 
           SET available = $1, "updatedAt" = $2 
           WHERE id = $3`,
          [available, updatedAt, variant.id]
        );
      } else {
        console.log("supressed");
        // Even if available matches, we should still update updatedAt if it's new
        await client.query(
          `UPDATE "InventoryGroupVariant" 
           SET "updatedAt" = $1 
           WHERE id = $2`,
          [updatedAt, variant.id]
        );
      }
    }

    await client.query('COMMIT');
    console.log('✅ Group sync completed successfully');

  } catch (error) {
    await client.query('ROLLBACK').catch(() => { });
    console.error('❌ Sync failed:', error);
    throw error;
  } finally {
    client.release();
  }
}

module.exports = { startConsumer };
