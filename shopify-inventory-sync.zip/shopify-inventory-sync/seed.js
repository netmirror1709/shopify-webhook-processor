const { Pool } = require('pg');
const fs = require('fs');
require('dotenv').config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL || "postgresql://postgres:postgres@localhost:5432/syncdb",
});

async function seed() {
  const client = await pool.connect();
  try {
    await client.query(`
      CREATE TABLE IF NOT EXISTS "InventoryGroupVariant" (
        id SERIAL PRIMARY KEY,
        "groupId" VARCHAR(255) NOT NULL,
        "productId" VARCHAR(255) NOT NULL,
        "productTitle" VARCHAR(255) NOT NULL,
        "variantId" VARCHAR(255) NOT NULL,
        "variantTitle" VARCHAR(255) NOT NULL,
        "inventoryItemId" VARCHAR(255) NOT NULL,
        "storeDomain" VARCHAR(255) NOT NULL,
        "storeAccessKey" VARCHAR(255) NOT NULL,
        "locationId" VARCHAR(255) NOT NULL,
        "available" INTEGER,
        "updatedAt" TIMESTAMP
      );
    `);
    
    // Clear old data
    await client.query('DELETE FROM "InventoryGroupVariant"');

    const data = [
      [1,"2480da91-1c30-4ee9-b8bc-495e8fa94575","gid://shopify/Product/8617694625942","Origami Crane Necklace","gid://shopify/ProductVariant/46264569168022","Default Title","gid://shopify/InventoryItem/48422189432982","yash-01.myshopify.com","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","gid://shopify/Location/73606004886",null],
      [2,"2480da91-1c30-4ee9-b8bc-495e8fa94575","gid://shopify/Product/8271230206022","Origami Crane Necklace","gid://shopify/ProductVariant/44693569470534","Default Title","gid://shopify/InventoryItem/46623588581446","yash-02.myshopify.com","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","gid://shopify/Location/80791404614",null],
      [3,"2480da91-1c30-4ee9-b8bc-495e8fa94575","gid://shopify/Product/7108404936753","Origami Crane Necklace","gid://shopify/ProductVariant/40928865976369","Default Title","gid://shopify/InventoryItem/43024803397681","yash-03.myshopify.com","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","gid://shopify/Location/66825519153",null],
      [4,"8aa168b4-8454-42a1-bd06-bcead48b29c4","gid://shopify/Product/8249984319558","The Inventory Not Tracked Snowboard","gid://shopify/ProductVariant/44663775952966","Default Title","gid://shopify/InventoryItem/46593479671878","yash-02.myshopify.com","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","gid://shopify/Location/80791404614",null],
      [5,"8aa168b4-8454-42a1-bd06-bcead48b29c4","gid://shopify/Product/8429251559559","The Inventory Not Tracked Snowboard","gid://shopify/ProductVariant/44008935489671","Default Title","gid://shopify/InventoryItem/46118735708295","yash-04.myshopify.com","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","gid://shopify/Location/82762137735",null],
      [6,"53ee5402-849e-4f62-9326-f06c626fad3b","gid://shopify/Product/8249984745542","The Multi-managed Snowboard","gid://shopify/ProductVariant/44663776215110","Default Title","gid://shopify/InventoryItem/46593479934022","yash-02.myshopify.com","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","gid://shopify/Location/80791404614",null],
      [7,"53ee5402-849e-4f62-9326-f06c626fad3b","gid://shopify/Product/8429251985543","The Multi-managed Snowboard","gid://shopify/ProductVariant/44008936013959","Default Title","gid://shopify/InventoryItem/46118736232583","yash-04.myshopify.com","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","gid://shopify/Location/82762137735",null],
      [8,"e155864e-30c1-46f5-8006-13287a7bc16c","gid://shopify/Product/8249984778310","The 3p Fulfilled Snowboard","gid://shopify/ProductVariant/44663776247878","Default Title","gid://shopify/InventoryItem/46593479966790","yash-02.myshopify.com","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","gid://shopify/Location/80791470150",null],
      [9,"e155864e-30c1-46f5-8006-13287a7bc16c","gid://shopify/Product/8429252018311","The 3p Fulfilled Snowboard","gid://shopify/ProductVariant/44008935981191","Default Title","gid://shopify/InventoryItem/46118736199815","yash-04.myshopify.com","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","gid://shopify/Location/82762203271",null],
      [10,"1efa5e6f-a869-4bf7-8b29-cac535384101","gid://shopify/Product/7108404871217","Moon Charm Bracelet","gid://shopify/ProductVariant/40928865910833","Default Title","gid://shopify/InventoryItem/43024803332145","yash-03.myshopify.com","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","gid://shopify/Location/66825519153",null],
      [11,"1efa5e6f-a869-4bf7-8b29-cac535384101","gid://shopify/Product/8429254574215","Moon Charm Bracelet","gid://shopify/ProductVariant/44008954921095","Default Title","gid://shopify/InventoryItem/46118755139719","yash-04.myshopify.com","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","gid://shopify/Location/82762137735",null],
      [12,"1efa5e6f-a869-4bf7-8b29-cac535384101","gid://shopify/Product/8271230074950","Moon Charm Bracelet","gid://shopify/ProductVariant/44693569437766","Default Title","gid://shopify/InventoryItem/46623588548678","yash-02.myshopify.com","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","gid://shopify/Location/80791404614",null]
    ];

    for (const row of data) {
      await client.query(`
        INSERT INTO "InventoryGroupVariant" 
        (id, "groupId", "productId", "productTitle", "variantId", "variantTitle", "inventoryItemId", "storeDomain", "storeAccessKey", "locationId", available, "updatedAt")
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
      `, [...row, new Date()]);
    }

    console.log("Seeding complete.");
  } catch (err) {
    console.error(err);
  } finally {
    client.release();
    pool.end();
  }
}

seed();
