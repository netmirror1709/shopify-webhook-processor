# Shopify Inventory Webhook Sync - Overview
The background service is set up to listen for Shopify inventory updates across stores, sync the `delta` to the other stores, and protect against infinite loop echoes and race conditions.

## Architectural Flow
```mermaid
sequenceDiagram
    participant S1 as Store A
    participant WP as Webhook Processor
    participant DB as Postgres (InventoryLevel)
    participant S2 as Store B

    S1->>WP: Webhook: Item Updated to 50
    WP->>DB: Check Timestamp & Prev Level
    WP-->>WP: Delta = 50 - 40 = 10
    WP->>DB: Upsert Base to 50
    WP->>DB: Bump Store B Base by +10 (Proactive Echo Resolution)
    WP->>S2: GraphQL AdjustQuantities +10
    
    Note over S2, WP: Shopify natively processes the adjustment<br/>and triggers an echo webhook back to us.
    S2->>WP: Webhook Echo: Item Updated to 70
    WP->>DB: Check Prev Level (which is now 70 because we bumped it)
    WP-->>WP: Delta = 70 - 70 = 0
    WP->>DB: Upsert Base to 70
    Note over WP: Webhook Ignored! Echo Stopped!

```

### How the problems were solved

#### Loop Echo Problem
We store the current available inventory count for each store locally.
When we sync an inventory adjustment to Store B, Shopify naturally fires an `inventory_levels/update` webhook back to us for Store B—this is an "echo".

By calculating the `delta` between the incoming webhook available count and our known `previous_available` count from the DB, we can determine the true magnitude of the change. If the `delta` is `0`, we can gracefully ignore the webhook without sending adjustments back to Store A—stopping the infinite loop!

#### Missing Delta Problem
Because Shopify's webhooks only send the absolute `available` count instead of the `delta`, we use our [InventoryLevel](file:///home/dev/workspace/shopify-webhook-processor/shopify-inventory-sync/consumer.js#182-318) DB table as a source of truth for our "last seen" inventory counts. Thus, `current_available - previous_known` gives us the exact delta to forward.

#### Race Conditions
What if we send an adjustment, but right before we do, Store B makes a sale organically? Webhooks may arrive out of order! We added an `updated_at` check on the DB table. When an out of order webhook arrives, we compare `webhook.updated_at < database.updatedAt` to silently drop old packets and preserve data integrity, ensuring that we never regress an inventory state.
